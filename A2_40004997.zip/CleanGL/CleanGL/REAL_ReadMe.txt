========================================================================
    CONSOLE APPLICATION : CleanGL Project Overview
========================================================================
NAME: Earl Steven Aromin
ID: 40004997
COURSE: COMP 371
ASSIGNMENT NUMBER: 1
/////////////////////////////////////////////////////////////////////////////
EXTERNAL SOURCES

GLuint loadShaders(std::string vertex_shader_path, std::string fragment_shader_path);
also for update_view() to Tim
Along with the template sent in piazza was used as a base for this. So.. credits to the TA's
glfw
learnopengl.com
Teacher Slides



=====================================================
ASSIGNMENT 2 STUFF
======================================================
KEYBINDING, SAME AS THE ONES IN LECTURE NOTES


https://github.com/nothings/stb/blob/master/stb_image.h















/////////////////////////////////////////////////////////////////////////////
KEYBINDINGS

===SIZE===
U = Scale up
J = Scale down

===CAMERA===
ARROW KEYS FOR ROTATION

'Home'= reset to the initial world position and orientation

while right button is pressed → use mouse movement in x direction to pan; and
while middle button is pressed → use mouse movement in y direction to tilt
while left button is pressed → use mouse movement to move into/out of the scene

change the rendering mode :
	key ‘P’ for points, 
	key ‘L’ for lines, 
	key ‘T’ for triangles

===HORSE MOVEMENT===
'Spacebar' = re-position the horse at a random location on the grid
 -Rotation-
	a → rotate 5 degrees about Y axis, 
	d → rotate other way 5 degrees about Y axis, 
	w → rotate upwards 5 degrees raising the front legs, 
	s → rotate downwards 5 degrees raising the hind legs

 -Walking-
	SHIFT + W - move one unit forward
	SHIFT + S - move one unit backward
	SHIFT + A - move one unit to left
	SHIFT + D - move one unit to right
